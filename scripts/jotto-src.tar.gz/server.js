"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
exports.__esModule = true;
var express_1 = __importDefault(require("express"));
var fs_1 = require("fs");
var body_parser_1 = __importDefault(require("body-parser"));
var path_1 = require("path");
var app = express_1["default"]();
app.use("/jotto", express_1["default"].static(path_1.join(__dirname, "public_html")));
app.use(body_parser_1["default"].json());
var port = process.env.NODE_PORT || 3900;
app.post("/jotto", function (req, res) {
    var f = "";
    if (req.body.agent === "UniformGreedy") {
        f = "uniformgreedy-v-human.csv";
    }
    else if (req.body.agent === "HGreedy") {
        f = "hgreedy-v-human.csv";
    }
    else {
        res
            .status(400)
            .contentType("application/json")
            .send(JSON.stringify({
            status: 400,
            message: "Invalid agent: " + req.body.agent
        }));
        return;
    }
    var filename = path_1.join(__dirname, "results", f);
    if (!req.body.results || req.body.results.length > 4096) {
        res
            .status(400)
            .contentType("application/json")
            .send(JSON.stringify({
            status: 400,
            message: "Invalid results: " + req.body.results
        }));
        return;
    }
    fs_1.promises
        .appendFile(filename, req.body.results)
        .then(function () {
        res
            .status(200)
            .contentType("application/json")
            .send(JSON.stringify({
            status: 200,
            message: "Accepted submission"
        }));
        return;
    })["catch"](function (reason) {
        res
            .status(500)
            .contentType("application/json")
            .send(JSON.stringify({
            status: 500,
            message: reason
        }));
        return;
    });
});
app.listen(port, function () {
    console.log("Started listening on port " + port + "...");
});
