---
name: Leaflet.Mapcodes
category: mouse-coordinates
repo: https://github.com/matlads/Leaflet.Mapcodes
author: Martin Atukunda
author-url: https://github.com/matlads
demo: http://matlads.github.io/Leaflet.Mapcodes/
compatible-v0:
compatible-v1: true
---

Displays the <a href="https://www.mapcode.com">Mapcode</a> of the mouse pointer on mouse move.
