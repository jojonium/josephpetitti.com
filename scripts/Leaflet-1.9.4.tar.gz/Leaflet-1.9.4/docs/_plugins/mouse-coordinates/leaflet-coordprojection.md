---
name: Leaflet.CoordProjection
category: mouse-coordinates
repo: https://github.com/edihasaj/leaflet-coord-projection
author: Edi Hasaj
author-url: https://github.com/edihasaj
demo: https://edihasaj.github.io/leaflet-coord-projection/
compatible-v0:
compatible-v1: true
---

Shows coordinates on mouse move and displays it based on given projection.
