---
name: leaflet-graphicscale
category: measurement
repo: https://github.com/nerik/leaflet-graphicscale
author: Erik Escoffier
author-url: https://github.com/nerik
demo: https://nerik.github.io/leaflet-graphicscale/demo/
compatible-v0:
compatible-v1: true
---

Animated graphic scale control.
