---
name: leaflet-measure
category: measurement
repo: https://github.com/ljagis/leaflet-measure
author: LJA GIS
author-url: https://github.com/ljagis
demo: 
compatible-v0:
compatible-v1: true
---

Coordinate, linear, and area measure control for Leaflet maps
