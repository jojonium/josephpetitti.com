---
name: Leaflet.PolylineMeasure
category: measurement
repo: https://github.com/ppete2/Leaflet.PolylineMeasure
author: PPete
author-url: https://github.com/ppete2
demo: https://ppete2.github.io/Leaflet.PolylineMeasure/demo1.html
compatible-v0:
compatible-v1: true
---

Measure great-circle distances of simple lines as well as of complex polylines.
