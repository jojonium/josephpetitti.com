---
name: Leaflet LocationIQ Geocoder
category: geocoding
repo: https://github.com/location-iq/leaflet-geocoder
author: LocationIQ
author-url: https://github.com/location-iq
demo: https://maps.locationiq.com/web_leaflet.php
compatible-v0:
compatible-v1: true
---

A plugin that adds the ability to search (geocode) a Leaflet-powered map using <a href="https://locationiq.com/">LocationIQ</a>.
