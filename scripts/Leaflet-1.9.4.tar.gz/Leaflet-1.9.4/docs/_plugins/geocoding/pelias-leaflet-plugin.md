---
name: Pelias Leaflet Plugin
category: geocoding
repo: https://github.com/pelias/leaflet-plugin
author: Lou Huang
author-url: https://github.com/louh
demo: https://pelias.github.io/leaflet-plugin/
compatible-v0:
compatible-v1: true
---

A geocoding control using <a href="https://geocode.earth">Geocode Earth</a> or any hosted service powered by the <a href="https://github.com/pelias/api">Pelias Geocoder API</a>.
