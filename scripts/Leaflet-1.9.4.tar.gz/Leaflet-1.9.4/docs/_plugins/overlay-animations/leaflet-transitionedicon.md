---
name: Leaflet.TransitionedIcon
category: overlay-animations
repo: https://github.com/naturalatlas/leaflet-transitionedicon
author: Brian Reavis
author-url: https://github.com/brianreavis
demo: http://naturalatlas.github.io/leaflet-transitionedicon/
compatible-v0:
compatible-v1: true
---

Transition in/out markers with CSS3 transitions. It supports jitter for staggering markers into view to prevent visual overload.
