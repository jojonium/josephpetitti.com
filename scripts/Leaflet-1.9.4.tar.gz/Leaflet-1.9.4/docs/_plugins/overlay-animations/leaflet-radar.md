---
name: Leaflet.Radar
category: overlay-animations
repo: https://github.com/cygis2011/leaflet-radar
author: cygis2011
author-url: https://github.com/cygis2011
demo: https://cygis2011.github.io/leaflet-radar/demo/index.html
compatible-v0: false
compatible-v1: true
---

Radar sector scan animation
