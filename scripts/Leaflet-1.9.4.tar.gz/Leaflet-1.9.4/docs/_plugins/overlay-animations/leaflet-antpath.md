---
name: Leaflet.AntPath
category: overlay-animations
repo: https://github.com/rubenspgcavalcante/leaflet-ant-path
author: Rubens Pinheiro
author-url: https://github.com/rubenspgcavalcante
demo: https://rubenspgcavalcante.github.io/leaflet-ant-path/
compatible-v0:
compatible-v1: true
---

Leaflet.AntPath put a flux animation (like ants walking) into a Polyline.
