---
name: leaflet-partition
category: dataviz
repo: https://github.com/locknono/leaflet-partition
author: locknono
author-url: https://github.com/locknono
demo: https://locknono.github.io/leaflet-partition/
compatible-v0:
compatible-v1: true
---

Divide the area into parts in different ways such as voronoi(triangulation) and hexagonal tiling.
