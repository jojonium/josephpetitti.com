---
name: leaflet-echarts
category: dataviz
repo: https://github.com/wandergis/leaflet-echarts
author: wandergis
author-url: https://github.com/wandergis
demo: https://wandergis.com/leaflet-echarts/index-en.html
compatible-v0:
compatible-v1: true
---

A plugin for Leaflet to load <a href="https://github.com/apache/echarts">echarts</a> map and make big data visualization easier.
