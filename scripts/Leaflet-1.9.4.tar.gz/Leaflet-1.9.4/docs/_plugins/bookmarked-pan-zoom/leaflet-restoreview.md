---
name: Leaflet.RestoreView
category: bookmarked-pan-zoom
repo: https://github.com/makinacorpus/Leaflet.RestoreView
author: Mathieu Leplatre
author-url: https://github.com/leplatrem
demo: https://makinacorpus.github.io/Leaflet.RestoreView/
compatible-v0:
compatible-v1: true
---

Stores and restores map view using localStorage.
