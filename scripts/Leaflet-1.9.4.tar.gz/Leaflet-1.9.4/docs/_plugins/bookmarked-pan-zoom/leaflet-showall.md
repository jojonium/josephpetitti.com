---
name: Leaflet.ShowAll
category: bookmarked-pan-zoom
repo: https://github.com/florpor/Leaflet.ShowAll
author: Mor Yariv
author-url: https://github.com/florpor
demo: http://florpor.github.io/Leaflet.ShowAll/examples/
compatible-v0:
compatible-v1: true
---

A control that can show a predefined extent while saving the current one so it can be jumped back to.
