---
name: Leaflet Locationlist
category: bookmarked-pan-zoom
repo: https://github.com/mithron/leaflet.locationlist
author: Ivan Ignatyev
author-url: https://github.com/mithron
demo: 
compatible-v0:
compatible-v1: true
---

A control to jump between predefined locations and zooms.
