---
name: Leaflet Navigation Toolbar
category: bookmarked-pan-zoom
repo: https://github.com/davidchouse/Leaflet.NavBar
author: David C
author-url: https://github.com/davidchouse
demo: http://davidchouse.github.io/Leaflet.NavBar/
compatible-v0:
compatible-v1: true
---

Leaflet control for simple back, forward and home navigation.
