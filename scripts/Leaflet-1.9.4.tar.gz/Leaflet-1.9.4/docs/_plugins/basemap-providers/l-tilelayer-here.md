---
name: L.TileLayer.HERE
category: basemap-providers
repo: https://gitlab.com/IvanSanchez/Leaflet.TileLayer.HERE
author: Iván Sánchez
author-url: https://github.com/IvanSanchez
demo: https://ivansanchez.gitlab.io/Leaflet.TileLayer.HERE/demo.html
compatible-v0:
compatible-v1: true
---

Displays map tiles from HERE maps.
