---
name: Leaflet-Tilelayer-Hong-Kong
category: basemap-providers
repo: https://github.com/spaceflighter/leaflet-tilelayer-hongkong
author: spaceflighter
author-url: https://github.com/spaceflighter
demo:
compatible-v0:
compatible-v1: true
---

Displays Hong Kong map tiles from <a href="https://geodata.gov.hk">Hong Kong GeoData Store</a> provider.
