---
name: Leaflet.ChineseTmsProviders
category: basemap-providers
repo: https://github.com/htoooth/Leaflet.ChineseTmsProviders
author: Tao Huang
author-url: https://github.com/htoooth/
demo: http://htoooth.github.io/Leaflet.ChineseTmsProviders/examples/indexTianDiTu.html
compatible-v0:
compatible-v1: true
---

Contains configurations for various Chinese tile providers — TianDiTu, MapABC, GaoDe, etc.
