---
name: Leaflet.MiniMap
category: minimaps-synced-maps
repo: https://github.com/Norkart/Leaflet-MiniMap
author: Robert Nordan
author-url: https://github.com/robpvn
demo: https://norkart.github.io/Leaflet-MiniMap/example.html
compatible-v0:
compatible-v1: true
---

A small minimap showing the map at a different scale to aid navigation.
