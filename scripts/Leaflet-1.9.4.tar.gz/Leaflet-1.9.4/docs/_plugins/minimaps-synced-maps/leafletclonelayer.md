---
name: leaflet-clonelayer
category: minimaps-synced-maps
repo: https://github.com/jieter/leaflet-clonelayer
author: Jieter
author-url: https://github.com/jieter
demo: 
compatible-v0:
compatible-v1: true
---

Clone Leaflet layers to allow reuse across different maps in the same runtime.
