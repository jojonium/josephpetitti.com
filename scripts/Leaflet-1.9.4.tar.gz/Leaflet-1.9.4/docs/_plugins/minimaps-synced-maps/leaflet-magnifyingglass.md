---
name: Leaflet.MagnifyingGlass
category: minimaps-synced-maps
repo: https://github.com/bbecquet/Leaflet.MagnifyingGlass
author: Benjamin Becquet
author-url: https://github.com/bbecquet/
demo: 
compatible-v0:
compatible-v1: true
---

Allows you to display a small portion of the map at another zoom level, either at a fixed position or linked to the mouse movement, for a magnifying glass effect.
