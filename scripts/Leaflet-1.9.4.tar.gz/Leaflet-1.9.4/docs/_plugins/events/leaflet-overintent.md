---
name: Leaflet.OverIntent
category: events
repo: https://github.com/makinacorpus/Leaflet.OverIntent
author: Mathieu Leplatre
author-url: https://github.com/makinacorpus/
demo: https://makinacorpus.github.io/Leaflet.OverIntent/
compatible-v0:
compatible-v1: true
---

Adds a new event ``mouseintent``, that differs from ``mouseover`` since it reflects user			intentions to aim a particular layer.
