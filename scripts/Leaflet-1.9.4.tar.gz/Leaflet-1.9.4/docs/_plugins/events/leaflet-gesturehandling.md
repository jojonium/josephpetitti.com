---
name: Leaflet.GestureHandling
category: events
repo: https://github.com/elmarquis/Leaflet.GestureHandling/
author: Andy Marquis
author-url: https://github.com/elmarquis
demo: https://elmarquis.github.io/Leaflet.GestureHandling/examples/
compatible-v0:
compatible-v1: true
---

Brings the basic functionality of Google Maps Gesture Handling into Leaflet. Prevents users from getting trapped on the map when scrolling a long page.
