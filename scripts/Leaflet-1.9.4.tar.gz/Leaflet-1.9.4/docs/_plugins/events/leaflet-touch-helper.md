---
name: Leaflet Touch Helper
category: events
repo: https://github.com/perliedman/leaflet-touch-helper
author: Per Liedman
author-url: https://github.com/perliedman
demo: https://www.liedman.net/leaflet-touch-helper/
compatible-v0:
compatible-v1: true
---

Makes it easy to touch vector overlays with thick fingers on a small display by adding a transparent, larger touch surface
