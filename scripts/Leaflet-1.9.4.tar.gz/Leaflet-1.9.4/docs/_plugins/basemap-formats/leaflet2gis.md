---
name: Leaflet-2gis
category: basemap-formats
repo: https://github.com/emikhalev/leaflet-2gis
author: Eugene Mikhalev
author-url: https://github.com/emikhalev/
demo: http://emikhalev.github.io/leaflet-2gis/
compatible-v0:
compatible-v1: true
---

Adds support for 2GIS tile layer
