---
name: L.Control.PaintPolygon
category: edit-geometries
repo: https://github.com/tcoupin/leaflet-paintpolygon
author: Thibault Coupin
author-url: https://github.com/tcoupin
demo: 
compatible-v0:
compatible-v1: true
---

Draw yours polygons with a circle brush like Paint[brush]. Includes turf.js dependencies.
