---
name: Leaflet.MapPaint
category: edit-geometries
repo: https://github.com/SINTEF-9012/Leaflet.MapPaint
author: Antoine Pultier
author-url: https://github.com/yellowiscool
demo: http://sintef-9012.github.io/Leaflet.MapPaint/
compatible-v0:
compatible-v1: true
---

Bitmap painting plugin designed for touch devices.
