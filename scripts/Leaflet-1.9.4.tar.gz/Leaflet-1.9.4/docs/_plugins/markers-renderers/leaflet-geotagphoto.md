---
name: Leaflet.GeotagPhoto
category: markers-renderers
repo: https://github.com/nypl-spacetime/Leaflet.GeotagPhoto
author: Bert Spaan
author-url: https://github.com/bertspaan
demo: http://spacetime.nypl.org/Leaflet.GeotagPhoto/examples/camera.html
compatible-v0:
compatible-v1: true
---

Plugin for photo geotagging, with two modes: camera and crosshair.
