---
name: leaflet-labeled-circle
category: markers-renderers
repo: https://github.com/w8r/leaflet-labeled-circle
author: Alexander Milevski
author-url: https://github.com/w8r/
demo: https://milevski.co/leaflet-labeled-circle/demo/
compatible-v0:
compatible-v1: true
---

Special type of SVG marker with a label inside and draggable around the anchor point.
