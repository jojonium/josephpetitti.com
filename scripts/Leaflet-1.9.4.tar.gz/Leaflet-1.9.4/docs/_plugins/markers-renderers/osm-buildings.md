---
name: OSM Buildings
category: markers-renderers
repo: https://osmbuildings.org/
author: Jan Marsch
author-url: https://github.com/kekscom/
demo: https://osmbuildings.org/
compatible-v0:
compatible-v1: true
---

Amazing JS library for visualizing 3D OSM building geometry on top of Leaflet.
