---
name: Leaflet.Sprite
category: markers-renderers
repo: https://github.com/leaflet-extras/leaflet.sprite
author: Calvin Metcalf
author-url: https://github.com/calvinmetcalf
demo: 
compatible-v0:
compatible-v1: true
---

Use sprite based icons in your markers.
