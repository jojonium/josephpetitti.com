---
name: leaflet-choropleth
category: markers-renderers
repo: https://github.com/timwis/leaflet-choropleth
author: Tim Wisniewski
author-url: https://timwis.com/
demo: https://timwis.com/leaflet-choropleth/examples/basic/
compatible-v0:
compatible-v1: true
---

Extends L.geoJson to add a choropleth visualization (color scale based on value).
