---
name: Leaflet.TextPath
category: markers-renderers
repo: https://github.com/makinacorpus/Leaflet.TextPath
author: Mathieu Leplatre
author-url: https://github.com/leplatrem
demo: https://makinacorpus.github.io/Leaflet.TextPath/
compatible-v0:
compatible-v1: true
---

Allows you to draw text along Polylines.
