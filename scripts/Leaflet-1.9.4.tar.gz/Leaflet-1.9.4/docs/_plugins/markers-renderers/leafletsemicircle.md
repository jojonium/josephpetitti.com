---
name: Leaflet-semicircle
category: markers-renderers
repo: https://github.com/jieter/Leaflet-semicircle
author: Jieter
author-url: https://github.com/jieter
demo: 
compatible-v0:
compatible-v1: true
---

Adds functionality to <code>L.Circle</code> to draw semicircles.
