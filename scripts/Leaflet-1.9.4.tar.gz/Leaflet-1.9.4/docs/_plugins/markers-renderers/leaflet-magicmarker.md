---
name: Leaflet.magicMarker
category: markers-renderers
repo: https://github.com/lit-forest/leaflet.magicMarker
author: Sylvenas
author-url: https://github.com/react-map
demo:
compatible-v0:
compatible-v1: true
---

Adding magical animation effect to a marker while loading.
