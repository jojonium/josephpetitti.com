---
name: Leaflet.curve
category: markers-renderers
repo: https://github.com/elfalem/Leaflet.curve
author: elfalem
author-url: https://github.com/elfalem
demo: http://elfalem.github.io/Leaflet.curve/
compatible-v0:
compatible-v1: true
---

A Leaflet plugin for drawing Bézier curves and other complex shapes.
