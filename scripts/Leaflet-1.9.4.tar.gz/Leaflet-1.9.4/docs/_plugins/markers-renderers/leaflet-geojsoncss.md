---
name: Leaflet.geojsonCSS
category: markers-renderers
repo: https://github.com/albburtsev/Leaflet.geojsonCSS
author: Alexander Burtsev
author-url: https://github.com/albburtsev/
demo: http://albburtsev.github.io/Leaflet.geojsonCSS/src/demo/demo.html
compatible-v0:
compatible-v1: true
---

<a href="https://wiki.openstreetmap.org/wiki/Geojson_CSS">Geojson CSS</a> implementation for Leaflet.
