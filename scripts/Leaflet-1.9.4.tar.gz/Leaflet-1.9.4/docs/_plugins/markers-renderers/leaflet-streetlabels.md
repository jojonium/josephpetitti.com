---
name: Leaflet.streetlabels
category: markers-renderers
repo: https://github.com/3mapslab/Leaflet.streetlabels
author: 3Maps
author-url: https://github.com/3mapslab
demo: https://3mapslab.github.io/Leaflet.streetlabels/
compatible-v0:
compatible-v1: true
---

A Leaflet plugin to show labels following the paths of polylines. An extension of yakitoritabetai Leaflet.LabelTextCollision.
