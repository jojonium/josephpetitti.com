---
name: Leaflet.orientedMarker
category: markers-renderers
repo: https://github.com/jekuno/leaflet.orientedMarker
author: jekuno
author-url: https://github.com/jekuno
demo: 
compatible-v0: true
compatible-v1: false
---

Allows to manage orientation of markers dynamically.
