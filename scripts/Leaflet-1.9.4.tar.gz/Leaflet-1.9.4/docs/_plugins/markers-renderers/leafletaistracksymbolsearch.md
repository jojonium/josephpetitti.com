---
name: leaflet-ais-tracksymbol-search
category: markers-renderers
repo: https://github.com/PowerPan/leaflet-ais-tracksymbol-search
author: Johannes Rudolph
author-url: https://github.com/powerpan
demo: 
compatible-v0:
compatible-v1: true
---

Adds a Search Box for your Leaflet Map and Your [leaflet-ais-trackymbol](https://github.com/PowerPan/leaflet-ais-tracksymbol)
