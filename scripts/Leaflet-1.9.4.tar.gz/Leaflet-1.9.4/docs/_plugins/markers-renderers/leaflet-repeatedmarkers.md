---
name: Leaflet.RepeatedMarkers
category: markers-renderers
repo: https://gitlab.com/IvanSanchez/Leaflet.RepeatedMarkers
author: Iván Sánchez
author-url: https://github.com/IvanSanchez
demo: https://ivansanchez.gitlab.io/Leaflet.RepeatedMarkers/demo.html
compatible-v0:
compatible-v1: true
---

Displays markers when wrapping around the globe, once every 360 degrees of longitude.
