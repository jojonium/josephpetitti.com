---
name: Leaflet-BetterScale
category: overlay-data-formats
repo: https://github.com/daniellsu/leaflet-betterscale
author: Dan Brown
author-url: https://github.com/daniellsu/
demo: https://daniellsu.github.io/leaflet-betterscale/
compatible-v0:
compatible-v1: true
---

A new, more GIS-like scalebar with alternating black/white bars.
