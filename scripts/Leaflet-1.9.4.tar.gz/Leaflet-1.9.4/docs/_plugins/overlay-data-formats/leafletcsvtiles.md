---
name: Leaflet-CsvTiles
category: overlay-data-formats
repo: https://github.com/gherardovarando/leaflet-csvtiles
author: Gherardo Varando
author-url: https://github.com/gherardovarando
demo: https://gherardovarando.github.io/leaflet-csvtiles/demo/index.html
compatible-v0:
compatible-v1: true
---

Load points from tiled csv files, using the amazing <a href="https://www.papaparse.com/">PapaParse</a> library.
