---
name: leaflet-omnivore
category: overlay-data-formats
repo: https://github.com/mapbox/leaflet-omnivore
author: Mapbox
author-url: https://github.com/mapbox
demo: https://docs.mapbox.com/mapbox.js/example/v1.0.0/omnivore-gpx/
compatible-v0:
compatible-v1: true
---

Loads &amp; converts CSV, KML, GPX, TopoJSON, WKT formats for Leaflet.
