---
name: heatmap.js
category: heatmaps
repo: https://www.patrick-wied.at/static/heatmapjs/plugin-leaflet-layer.html
author: Patrick Wied
author-url: https://github.com/pa7
demo: https://www.patrick-wied.at/static/heatmapjs/example-heatmap-leaflet.html
compatible-v0:
compatible-v1: true
---

JavaScript Library for HTML5 canvas based heatmaps.			Its Leaflet layer implementation supports large datasets because it is tile based and uses a quadtree index to store the data.
