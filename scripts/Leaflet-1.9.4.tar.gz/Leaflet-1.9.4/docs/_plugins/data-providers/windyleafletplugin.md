---
name: Windy-Leaflet-plugin
category: data-providers
repo: https://github.com/windycom/API
author: Windy.com
author-url: https://www.windy.com/
demo: https://www.windy.com/
compatible-v0:
compatible-v1: true
---

Displays animated weather map on your page using Windy's free API.
