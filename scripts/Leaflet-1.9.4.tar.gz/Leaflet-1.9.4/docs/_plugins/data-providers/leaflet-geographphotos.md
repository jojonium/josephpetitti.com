---
name: Leaflet.GeographPhotos
category: data-providers
repo: https://github.com/geograph-project/Leaflet.GeographPhotos
author: Barry Hunter
author-url: https://github.com/barryhunter/
demo: https://www.geograph.org/leaflet/Leaflet.GeographPhotos/GeographPhotos-example.html
compatible-v0:
compatible-v1: true
---

Display Geographical-Photos from Geograph Britain and Ireland in an interactive overlay, using their API.
