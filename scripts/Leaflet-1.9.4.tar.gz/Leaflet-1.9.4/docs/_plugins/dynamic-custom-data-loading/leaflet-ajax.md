---
name: Leaflet Ajax
category: dynamic-custom-data-loading
repo: https://github.com/calvinmetcalf/leaflet-ajax
author: Calvin Metcalf
author-url: https://github.com/calvinmetcalf/
demo: 
compatible-v0:
compatible-v1: true
---

Add GeoJSON data via ajax or jsonp.
