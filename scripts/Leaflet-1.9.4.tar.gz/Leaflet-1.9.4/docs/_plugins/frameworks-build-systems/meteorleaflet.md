---
name: meteor-leaflet
category: frameworks-build-systems
repo: https://github.com/bevanhunt/meteor-leaflet
author: Bevan Hunt
author-url: https://github.com/bevanhunt
demo: 
compatible-v0:
compatible-v1: true
---

Provides a Meteor package to quickly build real-time cross-platform map apps.
