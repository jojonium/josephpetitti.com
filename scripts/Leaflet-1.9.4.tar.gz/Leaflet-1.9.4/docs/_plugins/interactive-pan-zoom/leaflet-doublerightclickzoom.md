---
name: Leaflet.DoubleRightClickZoom
category: interactive-pan-zoom
repo: https://github.com/GhostGroup/Leaflet.DoubleRightClickZoom
author: Mike O'Toole
author-url: https://github.com/mikeotoole/
demo: http://ghostgroup.github.io/Leaflet.DoubleRightClickZoom/
compatible-v0:
compatible-v1: true
---

Interaction handler enabling zooming out with double right click.
