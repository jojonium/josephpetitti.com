---
name: Leaflet.BoxZoom
category: interactive-pan-zoom
repo: https://github.com/gregallensworth/L.Control.BoxZoom
author: Greg Allensworth
author-url: https://github.com/gregallensworth/L.Control.BoxZoom
demo: https://gregallensworth.github.io/L.Control.BoxZoom/
compatible-v0:
compatible-v1: true
---

A visible, clickable control to perform a box zoom.
