---
name: Leaflet.ZoomBox
category: interactive-pan-zoom
repo: https://github.com/consbio/Leaflet.ZoomBox
author: Brendan Ward
author-url: https://github.com/brendan-ward
demo: https://consbio.github.io/Leaflet.ZoomBox/
compatible-v0:
compatible-v1: true
---

A lightweight zoom box control: draw a box around the area you want to zoom to.
