---
name: Leaflet LimitZoom
category: interactive-pan-zoom
repo: https://github.com/Zverik/Leaflet.LimitZoom
author: Ilya Zverev
author-url: https://github.com/zverik
demo: https://zverik.github.io/Leaflet.LimitZoom/
compatible-v0:
compatible-v1: true
---

Plugins to limit available zoom levels to a given list, either by restricting zooming or by interpolating tiles.
