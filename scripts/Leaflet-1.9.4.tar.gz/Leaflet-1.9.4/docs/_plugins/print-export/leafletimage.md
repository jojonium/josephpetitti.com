---
name: Leaflet-image
category: print-export
repo: https://github.com/mapbox/leaflet-image
author: Tom MacWright
author-url: https://github.com/tmcw
demo: https://mapbox.github.io/leaflet-image/
compatible-v0:
compatible-v1: true
---

Export images out of Leaflet maps without a server component, by using Canvas and CORS.
