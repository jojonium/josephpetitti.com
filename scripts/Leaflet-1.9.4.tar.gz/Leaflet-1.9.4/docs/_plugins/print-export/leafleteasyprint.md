---
name: Leaflet-easyPrint
category: print-export
repo: https://github.com/rowanwins/leaflet-easyPrint
author: Rowan Winsemius
author-url: https://github.com/rowanwins
demo: https://rowanwins.github.io/leaflet-easyPrint/
compatible-v0:
compatible-v1: true
---

A simple plugin which adds an icon to print your Leaflet map.
