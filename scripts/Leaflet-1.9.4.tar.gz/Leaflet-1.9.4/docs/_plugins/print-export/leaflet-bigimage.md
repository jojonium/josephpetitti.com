---
name: Leaflet.BigImage
category: print-export
repo: https://github.com/pasichnykvasyl/Leaflet.BigImage
author: Vasyl Pasichnyk (Oswald)
author-url: https://github.com/pasichnykvasyl
demo: https://pasichnykvasyl.github.io/Leaflet.BigImage/
compatible-v0:
compatible-v1: true
---

Allows users to download an image with a scaled-up version of the visible map.
