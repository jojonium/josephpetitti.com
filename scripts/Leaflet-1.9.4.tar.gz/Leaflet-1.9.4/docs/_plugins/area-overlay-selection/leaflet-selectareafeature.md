---
name: Leaflet.SelectAreaFeature
category: area-overlay-selection
repo: https://github.com/sandropibia/Leaflet.SelectAreaFeature/
author: Sandro Pibia
author-url: https://github.com/sandropibia
demo: https://sandropibia.github.io/Leaflet.SelectAreaFeature/examples/index.html
compatible-v0:
compatible-v1: true
---

Selecting feature layers on a map by drawing an area.
