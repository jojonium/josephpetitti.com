---
name: leaflet-tooltip-layout
category: clustering-decluttering
repo: https://github.com/ZijingPeng/leaflet-tooltip-layout
author: Zijing Peng
author-url: https://github.com/ZijingPeng
demo: https://zijingpeng.github.io/overlapping-avoided-tooltip/
compatible-v0:
compatible-v1: true
---

A plugin to avoid tooltips overlapping and make it easier to find out the relationship between each tooltip and marker.
