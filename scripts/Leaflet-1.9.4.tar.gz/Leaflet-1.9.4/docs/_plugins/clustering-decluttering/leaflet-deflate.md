---
name: Leaflet.Deflate
category: clustering-decluttering
repo: https://github.com/oliverroick/Leaflet.Deflate
author: Oliver Roick
author-url: https://github.com/oliverroick
demo: 
compatible-v0:
compatible-v1: true
---

Deflates lines and polygons to a marker when their screen size becomes too small in lower zoom levels.
