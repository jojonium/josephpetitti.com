---
name: Greiner-Hormann
category: geoprocessing
repo: https://github.com/w8r/GreinerHormann
author: Alexander Milevski
author-url: https://github.com/w8r
demo: https://milevski.co/GreinerHormann/
compatible-v0:
compatible-v1: true
---

Greiner-Hormann algorithm for polygon clipping and binary operations, adapted for use with Leaflet.
