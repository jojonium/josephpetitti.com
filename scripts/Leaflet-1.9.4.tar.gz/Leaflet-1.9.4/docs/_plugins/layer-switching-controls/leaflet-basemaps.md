---
name: Leaflet.Basemaps
category: layer-switching-controls
repo: https://github.com/consbio/Leaflet.Basemaps
author: Brendan Ward
author-url: https://github.com/brendan-ward
demo: https://consbio.github.io/Leaflet.Basemaps/examples/toggle.html
compatible-v0:
compatible-v1: true
---

A basemap chooser with a preview image from the tile stack.			<a href="http://consbio.github.io/Leaflet.Basemaps/">Example</a>
