---
name: Leaflet.UniformControl
category: layer-switching-controls
repo: https://github.com/chriscalip/L.UniformControl
author: Chris Calip
author-url: https://github.com/chriscalip
demo: http://chriscalip.github.io/L.UniformControl/examples/layers-control-example-jeans.html
compatible-v0:
compatible-v1: true
---

Leaflet layer control with stylable checkboxes and radio buttons.
